function NSGAII(Global)
% <algorithm> <N>
% Nondominated sorting genetic algorithm II

%------------------------------- Reference --------------------------------
% K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, A fast and elitist
% multiobjective genetic algorithm: NSGA-II, IEEE Transactions on
% Evolutionary Computation, 2002, 6(2): 182-197.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Generate random population
    for prob=1:Global.num_of_problems
        Global.id = prob;
        Populations(prob,:) = Global.Initialization(prob);
        [~,FrontNos(prob,:),CrowdDiss(prob,:)] = EnvironmentalSelection(Populations(prob,:),Global.N);    
    end
%     Global.id = 1;
%     Population = Global.Initialization(1);
%     Global.id = 2;
%     Population2 = Global.Initialization(2);
%     [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,Global.N);
%     [~,FrontNo2,CrowdDis2] = EnvironmentalSelection(Population2,Global.N);

    myRMP=zeros(100,1);
    myGen = 0;
    
    runs = ones(Global.num_of_problems,1);
    run_1 = 1;
    run_2 = 1;
    
    %% Optimization
    for prob=1:Global.num_of_problems
        if runs(prob,:)>0
         if Global.NotTermination(Populations(prob,:),prob)
           MatingPools(prob,:) = TournamentSelection(2,Global.N,FrontNos(prob,:),-CrowdDiss(prob,:));
           Offsprings(prob,:)  = GA(Populations(prob,MatingPools(prob,:)),1);
           [Populations(prob,:),FrontNos(prob,:),CrowdDiss(prob,:)] = EnvironmentalSelection([Populations(prob,:),Offsprings(prob)],Global.N);
         else
             runs(prob,:) = 0;
         end
        end
    end
    
    for prob=1:Global.num_of_problems
        subpops(prob,:).data = [];
         for i = 1:length(Populations(prob,:))
                 subpops(prob,:).data = [subpops(prob,:).data;Populations(prob,i).dec];
         end        
    end
    
    vars=zeros(1,Global.num_of_problems)+Global.D;

    myRMP = learnRMP(subpops,vars) % learning RMP matrix online at every generation.
    myGen = myGen+1
        
%         if(rand() < temp)
%             MatingPool3 = [MatingPool(1,1:100),MatingPool2(1,1:100)];
%             Population3 = [Population(1,1:100),Population2(1,1:100)];
%            Offspring3  = GA(Population(MatingPool3),1);
%            [Population3,FrontNo3,CrowdDis3] = EnvironmentalSelection([Population3,Offspring3],Global.N);
%            [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Population3],Global.N);
% 
%         end
        
%     while sum(runs(:,1)) > 0
%         if run_1 > 0
%         if Global.NotTermination(Population,1)
%            MatingPool = TournamentSelection(2,Global.N,FrontNo,-CrowdDis);
%            Offspring  = GA(Population(MatingPool),1);
%            [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Offspring],Global.N);
%         end
%         else
%             run_1 = 0;
%         end
%         if run_2 > 0
%         if Global.NotTermination(Population2,2)       
%            MatingPool2 = TournamentSelection(2,Global.N,FrontNo2,-CrowdDis2);
%            Offspring2  = GA(Population2(MatingPool2),2);
%            [Population2,FrontNo2,CrowdDis2] = EnvironmentalSelection([Population2,Offspring2],Global.N);
%         end
%         else
%             run_2 = 0;
%         end
%         
%         subpops(1).data = [];
%         subpops(2).data = [];
%     
%          for i = 1:length(Population)
%                  subpops(1).data = [subpops(1).data;Population(i).dec];
%          end
%              
%          for i = 1:length(Population2)
%                  subpops(2).data = [subpops(2).data;Population2(i).dec];
%          end
%          
%          if myGen == 498
%              subpops(1).data;
%              subpops(2).data;
%          end
%          
%         vars=zeros(1,2);
%         vars(1) = Global.D;
%         vars(2) = Global.D;
%     
%         myRMP = learnRMP(subpops,vars); % learning RMP matrix online at every generation.
%         myGen = myGen+1;
%         temp = myRMP(1,2);
%         %temp = 0;
%         
%         if(rand() < temp)
%             MatingPool3 = [MatingPool(1,1:100),MatingPool2(1,1:100)];
%             Population3 = [Population(1,1:100),Population2(1,1:100)];
%            Offspring3  = GA(Population(MatingPool3),1);
%            [Population3,FrontNo3,CrowdDis3] = EnvironmentalSelection([Population3,Offspring3],Global.N);
%            [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Population3],Global.N);
% 
%         end
% 
%         %myGen
%         %if myGen == 29
%             
%         subpops(1).obj = [];
%         subpops(2).obj = [];
%     
%          for i = 1:length(Population)
%                  subpops(1).obj = [subpops(1).obj;Population(i).obj];
%          end
%              
%          for i = 1:length(Population2)
%                  subpops(2).obj = [subpops(2).obj;Population2(i).obj];
%          end
%          
%         score1 = IGD(subpops(1).obj, Global.problems{1}.PF);
%         score2 = IGD(subpops(2).obj, Global.problems{2}.PF);
% 
%         if score1 < 0.01
%             score1
%             myGen
%             break
%         end
%         if score2 < 1
%             score2;
%         end
%         %end
%         %rmp = RMP(1,2);
%         %RMP_Matrix(generation,1) = RMP_Matrix(generation,1) + rmp/30;
%         %assert(run_1 + run_2 > 0,'GLOBAL:Termination','Algorithm has terminated');
% 
%     end
end